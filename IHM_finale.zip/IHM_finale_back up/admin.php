<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="./css/admin.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="./css/header_insc.css">

    <title>Espace Admin</title>
</head>

<body>

    <div class="pages">
        <div class="heder">


            <div class="logo select">
                <a href="./index.php #acceuil"><img src="./images/logo2.png" alt=""> </a>
            </div>
            <div class="nav_bar">
                <a href="./index.php #acceuil" class="nav3 select">
                    <ul> Acceuil </ul>
                </a>
                <a href="#" class="nav0 select">
                    <ul>La carte</ul>
                </a>
                <a href="#" class="nav1 select">
                    <ul>Reserver</ul>
                </a>
                <a href="./index.php #contact" class="nav2 select">
                    <ul>Contact</ul>
                </a>

            </div>
            <div class="co_insc">
                <a href="./connexionAdmin.php" class="se_connecter select">
                    <h1>Se connecter</h1>
                </a>
                <a href="./Inscription.php" class="s_inscrire select">
                    <h1>S'inscrire</h1>
                </a>
            </div>
        </div>
        <?php require_once './process.php'?>
        <?php 
    if (isset($_SESSION['message'] )): ?>

        <div class="alert alert-<?=$_SESSION['msg_type']?> ">
            <?php
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        ?>
        </div>
        <?php endif ?>
        <div class="admin">
            <div class="side_menu">
                <div class="c_side">

                    <div class="client">Client</div>
                    <div class="produit">Produit</div>
                    <div class="categorie">Categorie</div>
                    <div class="administration">Administration</div>

                </div>
            </div>
            <div class="espace3">
                <?php  if (isset($_SESSION['message'])) : ?>
                <div class="alert alert-<?=$_SESSION['msg_type']?>">
                    <?php 
                 echo $_SESSION['message'];
                 unset($_SESSION['message']);?>

                </div>
                <?php endif ?>
                <div class="titre">
                    <?php
          $conn = new mysqli("localhost", "root", '', "chachnaq") or die(mysqli_error($conn)) ;
          $result =   $conn -> query( "SELECT * FROM produits")or die(mysqli_error($conn)) ;
                 
          ?>
                        Produit
                </div>
                <div class="tableux">
                    <table class="tcategorie">

                        <tread class="tread">
                            <td>Id produit</td>
                            <td>Nom produit</td>
                            <td>Categorie</td>
                            <td>Prix</td>
                            <td colspan="2">Action</td>
                        </tread>

                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <?php echo $row['idproduit'] ; ?>
                            </td>
                            <td>
                                <?php echo $row['nomProduit'] ;?>
                            </td>
                            <td>
                                <?php echo $row['Categorie'] ;?>
                            </td>
                            <td>
                                <?php echo $row['prix'] ;?>
                            </td>
                            <td>
                                <a href="admin_mod.php?edit=<?php echo $row['idproduit'] ;?>"> <input type="submit" id='submit' value='Modifier' id="midifier"> </a>
                            </td>
                            <td>
                                <a href="process.php?supp=<?php echo $row['idproduit'] ;?>"> <input type="submit" id='submit' value='Supprimer'></a>
                            </td>
                        </tr>

                        <?php endwhile ;?>


                        <a href="./admin_mod.php"> <input type="submit" id='submit' value='Supprimer'></a>

                </div>
            </div>
            
            </tbody>
            </table>
        </div>
    </div>
    </div>
    </div>
    
</body>

</html>