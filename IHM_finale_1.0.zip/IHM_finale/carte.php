<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="./css/carte.css">
    <link type="text/css" rel="stylesheet" href="./css/header.css">

    <title>Espace Admin</title>
</head>

<body>
    <!-- _______________________Header_______________________________________-->
    <div class="heder">

        <div class="logo select">
            <a href="./index.php #acceuil"><img src="./images/logo2.png" alt=""> </a>
        </div>
        <div class="nav_bar">
            <a href="./index.php #acceuil" class="nav3 select">
                <ul> Acceuil </ul>
            </a>
            <a href="#" class="nav0 select"  style= "color:black; background-color: white;">
                <ul style= "color:black; background-color: white;">La carte</ul>
            </a>
            <a href="#" class="nav1 select">
                <ul>Reserver</ul>
            </a>
            <a href="./index.php #contact" class="nav2 select">
                <ul>Contact</ul>
            </a>

        </div>
        <div class="co_insc">
            <a href="./connexionAdmin.php" class="se_connecter select">
                <h1>Se connecter</h1>
            </a>
            <a href="./Inscription.php" class="s_inscrire select">
                <h1>S'inscrire</h1>
            </a>
        </div>
    </div>
    <!--___________connection a la bdd____________________-->

    <?php
        $conn = new mysqli("localhost", "root", '', "chachnaq") or die(mysqli_error($conn)) ;                       
     ?>

    <!--___________corp____________________-->
    <div class="contenue">
        <div class="corp">

            <!--___________composant du menu____________________-->


            <!--___________Plat__________________-->
            <!--___________requette a la base de donner__________________-->
            <?php
                    $result =   $conn -> query( "SELECT * FROM produits WHERE Categorie = 'plat'")or die(mysqli_error($conn)) ;                          
                ?>
            <div class="plat">
                <div class="text">NOS <br> Plats</div>
                <div class="composant">
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="cont">
                        <div class="carte">
                        <div class="image"> <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).' " alt="Image" style="margin: 0 0 0 0 ; width: 100% ; height:100%;" >';?></div>
                        <div class="nom"><?php echo $row['nomProduit'] ;?></div>
                        <div class="description"><?php echo $row['description'] ;?></div>
                        <div class="prix"><?php echo $row['prix'] ;?></div>
                    </div>
                    <div class="arrier"></div>
                    </div>
                    <?php endwhile ;?>
                </div>

            </div>
            <!--___________Dessert__________________-->

            <!--___________requette a la base de donner__________________-->
            <?php
                    $result =   $conn -> query( "SELECT * FROM produits WHERE Categorie = 'dessert'")or die(mysqli_error($conn)) ;                          
                ?>
            <div class="dessert">
                <div class="text">NOS <br> Dessert</div>
                <div class="composant">
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="cont">
                        <div class="carte">
                        <div class="image"><?php echo '<img src="data:image;base64,'.base64_encode($row['image']).' " alt="Image" >';?></div>
                        <div class="nom"><?php echo $row['nomProduit'] ;?></div>
                        <div class="description"><?php echo $row['description'] ;?></div>
                        <div class="prix"><?php echo $row['prix'] ;?></div>
                    </div>
                    <div class="arrier"></div>
                    </div>
                    <?php endwhile ;?>
                </div>
            </div>
            <!--___________Boissons__________________-->

            <!--___________requette a la base de donner__________________-->
            <?php
                    $result =   $conn -> query( "SELECT * FROM produits WHERE Categorie = 'boisson'")or die(mysqli_error($conn)) ;                          
                ?>
            <div class="boissons">
                <div class="text">NOS <br> Boissons</div>
                <div class="composant">
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="cont">
                        <div class="carte">
                        <div class="image"> <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).' " alt="Image" >';?></div>
                        <div class="nom"><?php echo $row['nomProduit'] ;?></div>
                        <div class="description"><?php echo $row['description'] ;?></div>
                        <div class="prix"><?php echo $row['prix'] ;?></div>
                    </div>
                    <div class="arrier"></div>
                    </div>
                    <?php endwhile ;?>
                </div>
            </div>
        </div>
    </div>

</body>

</html>