<?php

session_start();
      //initialisation des variables 
        $nomproduit_ = '';
        $categorie_ = '';
        $prix_ ='';
        $update = false ;
        $id = 0 ;
// connection a la base de donner 
  $conn = new mysqli("localhost", "root", '', "chachnaq") or die(mysqli_error($conn)) ;
  if (isset($_POST['submit'])){
    
    $nomproduit =$_POST['nomProduit'];
    $categorie =$_POST['Categorie'];
    $prix =$_POST['prix'];
    
    
    $conn -> query( "INSERT INTO produits VALUES (NULL, '$nomproduit' ,'$categorie' , '$prix' )");
    $_SESSION['message'] = 'ajout effectuer avec succer ';
    $_SESSION['msg_type'] = 'success';
    header("location:admin.php");
  }
  
  if (isset($_GET['supp'])){
    $id =$_GET['supp'];

    $conn -> query( "DELETE FROM produits WHERE idproduit=$id") or die(mysqli_error($conn));
    
    $_SESSION['message'] = 'le supression a ete effectuer avec succer ';
    $_SESSION['msg_type'] = 'danger';
    header("location:admin.php");

  }
   

   if ( isset($_GET['edit'])){
    $id =$_GET['edit'];
    $update = true ;
    $resultat = $conn -> query( "SELECT * FROM produits WHERE idproduit=$id") or die(mysqli_error($conn));
 
        $row =$resultat ->fetch_array();
        $nomproduit_ = $row['nomProduit'];
        $categorie_ = $row['Categorie'];
        $prix_ = $row['prix'];
   }
   

if ( isset($_POST['update'])){
    $id =$_POST['id'];
    $nomproduit =$_POST['nomProduit'];
    $categorie =$_POST['Categorie'];
    $prix =$_POST['prix'];
    
    $resultat = $conn -> query( "UPDATE produits SET  nomProduit='$nomproduit' , Categorie = '$categorie' ,prix = '$prix' WHERE idproduit=$id ") or die(mysqli_error($conn));
    $_SESSION['message'] = 'Le produit a bien ete modifier  ';
    $_SESSION['msg_type'] = 'warning';
      
    header('location:admin.php');

   }
   ?>